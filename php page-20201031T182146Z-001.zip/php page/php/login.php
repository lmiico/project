<?php

$db = mysqli_connect('localhost','root','','qrsystem');

if($db){ echo "connection SUCCESS"; }

if(!$db){ echo "connection Failed"; }

if (isset($_POST['submit'])){

	
	$ID = $_POST['ID'];
	$password = $_POST['password'];

	$sql = "SELECT * FROM login WHERE ID = '".$ID."' AND Password = '".$Password."'";

	$result = mysqli_query($db,$sql);
	$count = mysqli_num_rows($result);

	if ($count == 1) {
		echo json_encode("Success");
	}else{
		echo json_encode("Error");
	}

}


?>