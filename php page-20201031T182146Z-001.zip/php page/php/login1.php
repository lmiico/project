<?php

$HostName = "localhost";
 $DatabaseName = 'qrsystem';
$HostUser = "root";
 $HostPass = ""; 
$db = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
if (isset($_POST['submit'])){
if(!$db){ echo "connection Failed"; }

$Name = $_['Name'];
$password = $_['password'];

$queryResult= "SELECT * FROM login WHERE Name = '".$Name."' AND Password = '".$Password."'";

$result =array();

while($fetchData=$queryResult->fetch_assoc()){
$result[]=$fetchData;
}}
?>