<?php

$db = mysqli_connect("localhost","root","","qrsystem");

if($db){ echo "connection SUCCESS"; }

if(!$db){ echo "connection Failed"; }


 if (isset($_POST['check'])){

$ID = $_POST['ID'];

$Name= $_POST['Name'];

$Email=$_POST['Email'];

$PhoneNumber= $_POST['PhoneNumber'];

$Level= $_POST['Level'];

$Password = $_POST['Password'];

 

$sql= "SELECT * FROM users WHERE ID ='".$ID."' AND Name ='".$Name."'AND Email= '".$Email."'AND Phone = '".$PhoneNumber."'AND Level='".$Level."'AND Password = '".$Password."'";

 

$result = mysqli_query($db,$sql);

$count = mysqli_num_rows ($result );

 

if($count==1){ 

echo json_encoded("Error"); 

}else{

	$insert ="INSERT INTO users(ID,Name, Email, Phone,Level,Password)VALUES(ID ='".$ID."' AND Name ='".$Name."'AND Email= '".$Email."'AND Phone = '".$PhoneNumber."'AND Level='".$Level."'AND Password = '".$Password."')";
	$query = mysqli_query($db,$insert);
if($query){

 echo json_encoded("SUCCESS"); 

}
}}

 ?>