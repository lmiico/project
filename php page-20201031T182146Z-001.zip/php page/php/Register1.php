 <?php


$HostName = "localhost";
 $DatabaseName = 'qrsystem';
$HostUser = "root";
 $HostPass = "";
$con = mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);

if (isset($_POST['submit'])){
$ID = $_POST["ID"];
$Name = $_POST["Name"];
$Email = $_POST["Email"];
$PhoneNumber = $_POST["PhoneNumber"];
$Level = $_POST["Level"];
$Password = $_POST["Password"];

$query = "SELECT * FROM voter_profile WHERE Email = '$Email'";

$res = mysqli_query($connect,$query);

$data = mysqli_fetch_array($res);

if($data[0] > 1){
    echo json_encode("Account already exists!");
}else{
    $query = "INSERT INTO voter_profile(ID, Name,Email,PhoneNumber,Level, Password)
                VALUES ('$ID', '$Name', '$Email', '$PhoneNumber', '$Level', '$Password', NULL)";
    $res = mysqli_query($query);

    if($res){
        echo json_encode("Success");
    }else{
        echo json_encode("Error");
    }
}
}
?>
