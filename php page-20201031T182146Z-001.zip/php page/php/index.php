<?php
include "connect.php" ;
$sql ="SELECT * FROM academiccalendar";
$stmt =$con->prepare($sql);
$stmt->execute();
$academiccalendar=$stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($academiccalendar);
?>